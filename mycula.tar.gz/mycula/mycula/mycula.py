from ctypes import *
import numpy as np
import mycula_utils as utils
import copy

from distutils.sysconfig import get_python_lib
lib_dir = get_python_lib() + '/mycula/lib'
lcula = cdll.LoadLibrary('libcula_lapack.so')
scula = cdll.LoadLibrary(lib_dir+'/cula_solo.so')
pcula = cdll.LoadLibrary(lib_dir+'/pcula.so')
culaDChost = cdll.LoadLibrary(lib_dir+'/cula_DC_host.so')
culaDC = cdll.LoadLibrary(lib_dir+'/cula_DC.so')

# Initialize CULA library
def culainit():
    info = lcula.culaInitialize()
    if info != 0:
        raise NotImplemetedError('cannot cula init')

# Shutdown CULA library
def culashutdown():
    info = lcula.culaShutdown()
    if info != 0:
        raise NotImplemetedError('cannot cula shutdown')

# Free buffer memory for using CULA
def culafreebuffers():
    info = lcula.culaFreeBuffers()
    if info != 0:
        raise NotImplemetedError('cannot cula free buffers')

# CULA status check
def culacheck(status, funcname):
    scula.checkStatus(status, funcname)

# copy Lower block of matrix to upper block (not diagonal)
# for acceleration computing trtri
def make_blockcash(block1, block2, npix):
    culaDC.make_trtri_cash_v2(block1.ctypes.data_as(POINTER(c_double)), block2.ctypes.data_as(POINTER(c_double)), c_int(npix))

# compute Dportf
def culaDpotrf(A, npix):
    scula.cula_potrf(A.ctypes.data_as(POINTER(c_double)), c_int(npix))

# compute Dtrtri
def culaDtrtri(A, npix):
    scula.cula_trtri(A.ctypes.data_as(POINTER(c_double)), c_int(npix))

# compute Dgemm
def culaDgemm(A, B, C, m, transa = 'N', transb = 'N', alpha = 1.0, beta = 1.0, n = 0, k = 0, lda = 0, ldb = 0, ldc = 0):
    if n == 0:
        n = m
    if k == 0:
        k = m
    if lda == 0:
        lda = m
    if ldb == 0:
        ldb = m
    if ldc == 0:
        ldc = m
    scula.cula_gemm(c_char(transa), c_char(transb), c_int(m), c_int(n), c_int(k),
            c_double(alpha), A.ctypes.data_as(POINTER(c_double)), c_int(lda),
            B.ctypes.data_as(POINTER(c_double)), c_int(ldb), c_double(beta),
            C.ctypes.data_as(POINTER(c_double)), c_int(ldc))

# compute Dtrmv from cublas library
def culaDtrmv(L, x, npix, uplo = 'L', transa = 'N', diag = 'N'):
    scula.cula_trmv(L.ctypes.data_as(POINTER(c_double)),
            x.ctypes.data_as(POINTER(c_double)), c_int(npix),
            uplo, transa, diag)

# compute Ddot from cublas library
def culaDdot(x, npix):
    scula.cula_dot.restype = c_double
    y = scula.cula_dot(x.ctypes.data_as(POINTER(c_double)), c_int(npix))
    return y

# compute Dpotrf from pCULA, using nGPU
def pculaDpotrf(A, npix):
    pcula.pcula_potrf(A.ctypes.data_as(POINTER(c_double)), c_int(npix))

# compute Dgemm from pCULA, using nGPU
def pculaDgemm(m, n, k, alpha, A, lda, B, ldb, beta, C, ldc, transa = 'N', transb = 'N'):
    pcula.pcula_gemm(c_char(transa), c_char(transb), c_int(m),c_int(n), c_int(k), c_double(alpha),
            A.ctypes.data_as(POINTER(c_double)), c_int(lda),
            B.ctypes.data_as(POINTER(c_double)), c_int(ldb), c_double(beta),
            C.ctypes.data_as(POINTER(c_double)), c_int(ldc))

# compute Dtrsm from pCULA, using nGPU
def pculaDtrsm(m, n, alpha, A, lda, B, ldb, side = 'R', uplo = 'L', transa = 'T', diag = 'N'):
    pcula.pcula_trsm(c_char(side), c_char(uplo), c_char(transa), c_char(diag), c_int(m), c_int(n), c_double(alpha),
            A.ctypes.data_as(POINTER(c_double)), c_int(lda),
            B.ctypes.data_as(POINTER(c_double)), c_int(ldb))

# compute Dpotrf from my cula library, using nGPU
def myPculaDpotrf(cov, divide, ngpu, p_option = False, calc_p = False):
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    culaDChost.ppotrf(block.ctypes.data_as(POINTER(c_double)), c_int(npix), c_int(divide), c_int(ngpu), p_option, calc_p)
    utils.join_matrix(cov, block, divide)

# compute Dtrtri from my cula library, using nGPU
def myPculaDtrtri(cov, divide, ngpu, p_option = False, calc_p = False):
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    culaDChost.ptrtri(block.ctypes.data_as(POINTER(c_double)), c_int(npix), c_int(divide), c_int(ngpu), p_option, calc_p)
    utils.join_matrix(cov, block, divide)

# compute Dpotri from my cula library, using nGPU
def myPculaDpotri(cov, divide, ngpu, p_option = False, calc_p = False):
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    culaDChost.ppotrf(block.ctypes.data_as(POINTER(c_double)), c_int(npix), c_int(divide), c_int(ngpu), p_option, calc_p)
    culaDChost.ptrtri(block.ctypes.data_as(POINTER(c_double)), c_int(npix), c_int(divide), c_int(ngpu), p_option, calc_p)
    utils.join_matrix(cov, block, divide)

# trmv using Divide and Conqure from my cula library
def culaDtrmv(cov, x, divide, uplo = 'L', transa = 'N', diag = 'N'):
    culainit()
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    culaDChost.trmv(block.ctypes.data_as(POINTER(c_double)), x.ctypes.data_as(POINTER(c_double)), c_int(npix), c_int(divide), c_char(uplo), c_char(transa), c_char(diag))
    del block

# trmv using Divide and Conqure from my cula library, using scheduler
def culaDtrmv_v2(cov, x, divide, uplo = 'L', transa = 'N', diag = 'N'):
    culainit()
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    x = x.reshape(divide, npix)
    y = copy.deepcopy(x)
    sch_trmv = utils.set_trmv_alg(divide)
    length = len(sch_trmv)
    for i in xrange(length):
        culaDC.trmv_calc(block[sch_trmv[i][1]].ctypes.data_as(POINTER(c_double)),
                x[sch_trmv[i][2]].ctypes.data_as(POINTER(c_double)),
                y[sch_trmv[i][3]].ctypes.data_as(POINTER(c_double)),
                sch_trmv.ctypes.data_as(POINTER(c_int)), c_int(i),
                c_int(npix), c_int(divide), c_char(uplo), c_char(transa), c_char(diag))
    del block
    return y.reshape(pix)

# compute Dpotrf from my cula library, using nGPU and scheduler
def myPculaDpotrf_v2(cov, divide, ngpu, p_option = False, sch_p = False):
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    length = utils.set_sch_len(divide)
    sch_potrf = utils.set_potrf_alg(divide, ngpu, sch_p)
    for i in xrange(length):
        func_num = 0
        for j in xrange(ngpu):
            func_num += sch_potrf[ngpu*i+j][0]
        if func_num != 0:
            culainit()
            if ngpu == 1:
                culaDC.calc_single(block[sch_potrf[i][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[i][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[i][3]].ctypes.data_as(POINTER(c_double)),
                            sch_potrf.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            elif ngpu <= 3:
                    culaDC.calc_triple(block[sch_potrf[ngpu*i][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i][3]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i+1][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i+1][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i+1][3]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i+2][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i+2][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[ngpu*i+2][3]].ctypes.data_as(POINTER(c_double)),
                            sch_potrf.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            culafreebuffers()
            culashutdown()

    utils.join_matrix(cov, block, divide)

# compute Dtrtri from my cula library, using nGPU and scheduler
def myPculaDtrtri_v2(cov, divide, ngpu, p_option = False, sch_p = False):
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    length = utils.set_sch_len(divide)
    sch_trtri = utils.set_trtri_alg(divide, ngpu, sch_p)
    for i in xrange(divide):
        for j in xrange(i+1, divide):
            make_blockcash(block[divide*i+j], block[divide*j+i], npix)
    for i in xrange(length):
        func_num = 0
        for j in xrange(ngpu):
            func_num += sch_trtri[ngpu*i+j][0]
        if func_num != 0:
            culainit()
            if ngpu == 1:
                culaDC.calc_single(block[sch_trtri[i][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[i][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[i][3]].ctypes.data_as(POINTER(c_double)),
                            sch_trtri.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            elif ngpu <= 3:
                    culaDC.calc_triple(block[sch_trtri[ngpu*i][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i][3]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i+1][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i+1][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i+1][3]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i+2][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i+2][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[ngpu*i+2][3]].ctypes.data_as(POINTER(c_double)),
                            sch_trtri.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            culafreebuffers()
            culashutdown()

    utils.join_matrix(cov, block, divide)

# compute Dpotri from my cula library, using nGPU and scheduler
def myPculaDpotri_v2(cov, divide, ngpu, p_option = False, sch_p = False):
    pix = len(cov)
    npix = pix/divide
    block = utils.divide_matrix(cov, divide)
    length = utils.set_sch_len(divide)

    sch_potrf = utils.set_potrf_alg(divide, ngpu, sch_p)
    for i in xrange(length):
        func_num = 0
        for j in xrange(ngpu):
            func_num += sch_potrf[ngpu*i+j][0]
        if func_num != 0:
            culainit()
            if ngpu == 1:
                culaDC.calc_single(block[sch_potrf[i][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[i][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_potrf[i][3]].ctypes.data_as(POINTER(c_double)),
                            sch_potrf.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            elif ngpu <= 3:
                culaDC.calc_triple(block[sch_potrf[ngpu*i][1]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i][2]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i][3]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i+1][1]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i+1][2]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i+1][3]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i+2][1]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i+2][2]].ctypes.data_as(POINTER(c_double)),
                        block[sch_potrf[ngpu*i+2][3]].ctypes.data_as(POINTER(c_double)),
                        sch_potrf.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            culafreebuffers()
            culashutdown()

    sch_trtri = utils.set_trtri_alg(divide, ngpu, sch_p)
    for i in xrange(divide):
        for j in xrange(i+1, divide):
            make_blockcash(block[divide*i+j], block[divide*j+i], npix)
    for i in xrange(length):
        func_num = 0
        for j in xrange(ngpu):
            func_num += sch_trtri[ngpu*i+j][0]
        if func_num != 0:
            culainit()
            if ngpu == 1:
                culaDC.calc_single(block[sch_trtri[i][1]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[i][2]].ctypes.data_as(POINTER(c_double)),
                            block[sch_trtri[i][3]].ctypes.data_as(POINTER(c_double)),
                            sch_trtri.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            elif ngpu <= 3:
                culaDC.calc_triple(block[sch_trtri[ngpu*i][1]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i][2]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i][3]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i+1][1]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i+1][2]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i+1][3]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i+2][1]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i+2][2]].ctypes.data_as(POINTER(c_double)),
                        block[sch_trtri[ngpu*i+2][3]].ctypes.data_as(POINTER(c_double)),
                        sch_trtri.ctypes.data_as(POINTER(c_int)), c_int(i), c_int(npix), c_int(ngpu), p_option)
            culafreebuffers()
            culashutdown()

    utils.join_matrix(cov, block, divide)

