cusparse.py
-> suda sparse library, 全部関数内で変換している

cusparse_gemm
->
    1. cusparseXcsrgemmNnz
       csrRowPtrの内容とcsrColIndex,csrValの長さ(nnzTotalDevHostPtr.value)を求める
    2. cusparseDgemm
       csrRowPtrの結果とcsrColIndex,csrValの配列を使ってgemmを計算する
       ポインタ渡しで処理しているので、結果は更新されている
注意: 行列は一般行列しか使えない
    　よって、MatDecrは何も触れません
      転置がしたい場合は、
      csrをcscに変換 + csrRowPtr <= cscColPtr & csrColIndex <= cscRowIndexとinputを変換

csr2coo, coo2csrの行列変換, cudaを使っているのでそこそこ早いと思われる
cusparseXcsr2coo
cusparseXcoo2csr
