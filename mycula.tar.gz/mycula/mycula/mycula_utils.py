import numpy as np
from ctypes import *
import copy

#{{{ utility
def divide_matrix(matrix, divide):
    pix = len(matrix)
    npix = pix / divide
    tile = np.zeros((divide*divide, npix, npix), dtype=np.float64)
    for i in xrange(divide):
        for j in xrange(divide):
            tile[divide*i+j][:,:] = copy.deepcopy(matrix[i*npix:(i+1)*npix, j*npix:(j+1)*npix])
    tile = tile.reshape(divide*divide, npix*npix)
    return tile

def join_matrix(matrix, tile, divide):
    pix = len(matrix)
    npix = pix / divide
    tile = tile.reshape(divide*divide, npix, npix)
    for i in xrange(divide):
        for j in xrange(divide):
            matrix[i*npix:(i+1)*npix, j*npix:(j+1)*npix] = tile[divide*i+j][:,:]
    del tile
    return

#}}}

#{{{ set algorithm
def set_sch_len(divide):
    len = 0
    if divide == 1:
        len = 1
    else:
        for i in xrange(divide/2):
            len += 2*(i+1)*(divide-i)

    return len
def set_potrf_alg(divide, ngpu, p_option = False):

    # set schedule length
    len = set_sch_len(divide)
    # init schedule
    sch = np.zeros((ngpu*len,4),dtype=np.int32)
    # set schedule
    col = 0
    for i in xrange(divide):
        row = 0
        sch[ngpu*col + row][0] = 1 # mean of 1 is potrf
        sch[ngpu*col + row][1] = divide * i + i
        col += 1
        row = 0
        for j in xrange(i+1,divide):
            sch[ngpu*col + row][0] = 2 # mean of 2 is trsm
            sch[ngpu*col + row][1] = divide * i + i
            sch[ngpu*col + row][2] = divide * i + j
            row += 1
            if row == ngpu:
                row = 0
                col += 1
        if row != 0:
            col += 1
        row = 0
        for j in xrange(i+1,divide):
            sch[ngpu*col + row][0] = 3 # mean of 3 is syrk
            sch[ngpu*col + row][1] = divide * j + j
            sch[ngpu*col + row][2] = divide * i + j
            row += 1
            if row == ngpu:
                row = 0
                col += 1
        for j in xrange(i+1,divide-1):
            for k in xrange(j+1,divide):
                sch[ngpu*col + row][0] = 4 # mean of 4 is gemm
                sch[ngpu*col + row][1] = divide * i + k
                sch[ngpu*col + row][2] = divide * i + j
                sch[ngpu*col + row][3] = divide * j + k
                row += 1
                if row == ngpu:
                    row = 0
                    col += 1
        if row != 0:
            col += 1
        row = 0

    # if p_option is True, print schedule
    if p_option:
        for i in xrange(len):
            for j in xrange(ngpu):
                if sch[ngpu*i + j][0] != 0:
                    print "gpu :",j,"cal :",sch[ngpu*i + j][0]
    return sch

def set_trtri_alg(divide,ngpu,p_option = False):

    # set schedule length
    len = set_sch_len(divide)
    # init schedule
    sch = np.zeros((ngpu*len,4),dtype=np.int32)
    # set schedule
    row = 0
    col = 0
    for i in xrange(divide):
        sch[ngpu*col + row][0] = 5 # mean of 5 is trtri
        sch[ngpu*col + row][1] = divide * i + i
        row += 1
        if row == ngpu:
            row = 0
            col += 1
    if row != 0:
        col += 1
    row = 0
    for i in xrange(divide):
        for j in xrange(i+1,divide):
            sch[ngpu*col + row][0] = 6 # mean of 6 is trmmr
            sch[ngpu*col + row][1] = divide * i + i
            sch[ngpu*col + row][2] = divide * i + j
            row += 1
            if row == ngpu:
                row = 0
                col += 1
    if row != 0:
        col +=1
    row = 0
    for i in xrange(1,divide):
        row = 0
        for j in xrange(divide-i):
            sch[ngpu*col + row][0] = 7 # mean of 7 is trmml
            sch[ngpu*col + row][1] = divide * (j+i) + (j+i)
            sch[ngpu*col + row][2] = divide * j + (j+i)
            row += 1
            if row == ngpu:
                row = 0
                col += 1
        if row != 0:
            col += 1
        row = 0
        for j in xrange(divide-i):
            for k in xrange(j+i+1,divide):
                sch[ngpu*col + row][0] = 8 # mean of 8 is gemm
                sch[ngpu*col + row][1] = divide * k + (j+i)
                sch[ngpu*col + row][2] = divide * j + (j+i)
                sch[ngpu*col + row][3] = divide * j + k
                row += 1
                if row == ngpu:
                    row = 0
                    col += 1
        if row != 0:
            col += 1
        row = 0
    # if p_option is True, print schedule
    if p_option:
        for i in xrange(len):
            for j in xrange(ngpu):
                if sch[ngpu*i + j][0] != 0:
                    print "gpu :",j,"cal :",sch[ngpu*i + j][0]

    return sch

def set_trmv_alg(divide):
    length = 0
    l = np.arange(divide)+1
    length = l.sum()
    sch = np.zeros((length, 4), dtype=np.int32)
    col = 0
    for i in xrange(divide):
        sch[col][0] = 10 # mean of 10 is trmv
        sch[col][1] = divide*i + i # tile matrix index
        sch[col][2] = i # separated vector index (original)
        sch[col][3] = i # separated vector index (returns)
        col += 1
    for i in xrange(divide):
        for j in xrange(i+1, divide):
            sch[col][0] = 11 # mean of 11 is gemv
            sch[col][1] = divide*i + j
            sch[col][2] = i
            sch[col][3] = j
            col += 1
    return sch

#}}}

# vim: foldmethod=marker
