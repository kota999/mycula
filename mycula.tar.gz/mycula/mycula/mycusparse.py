import sys
import ctypes
import ctypes.util
import numpy as np
import pycuda.gpuarray as gpuarray
import scikits.cuda as cuda

_libcusparse_libname = 'libcusparse.so.5.0.35'
_libcusparse = ctypes.cdll.LoadLibrary(_libcusparse_libname)

if _libcusparse == None:
    OSError('CuSparse library not found')

class cusparseError(Exception):
    """CUSPARSE error"""
    pass

class cusparseStatusNotInitialized(cusparseError):
    """CUSPARSE library not initialized"""
    pass

class cusparseStatusAllocFailed(cusparseError):
    """CUSPARSE resource allocation failed"""
    pass

class cusparseStatusInvalidValue(cusparseError):
    """Unsupported value passed to the function"""
    pass

class cusparseStatusArchMismatch(cusparseError):
    """Function requires a feature absent from the device architecture"""
    pass

class cusparseStatusMappingError(cusparseError):
    """An access to GPU memory space failed"""
    pass

class cusparseStatusExecutionFailed(cusparseError):
    """GPU program failed to execute"""
    pass

class cusparseStatusInternalError(cusparseError):
    """An internal CUSPARSE operation failed"""
    pass

class cusparseStatusMatrixTypeNotSupported(cusparseError):
    """The matrix type is not supported by this function"""
    pass

cusparseExceptions = {
    1: cusparseStatusNotInitialized,
    2: cusparseStatusAllocFailed,
    3: cusparseStatusInvalidValue,
    4: cusparseStatusArchMismatch,
    5: cusparseStatusMappingError,
    6: cusparseStatusExecutionFailed,
    7: cusparseStatusInternalError,
    8: cusparseStatusMatrixTypeNotSupported,
    }

# Matrix types:
CUSPARSE_MATRIX_TYPE_GENERAL = 0
CUSPARSE_MATRIX_TYPE_SYMMETRIC = 1
CUSPARSE_MATRIX_TYPE_HERMITIAN = 2
CUSPARSE_MATRIX_TYPE_TRIANGULAR = 3

CUSPARSE_FILL_MODE_LOWER = 0
CUSPARSE_FILL_MODE_UPPER = 1

# Whether or not a matrix' diagonal entries are unity:
CUSPARSE_DIAG_TYPE_NON_UNIT = 0
CUSPARSE_DIAG_TYPE_UNIT = 1

# Matrix index bases:
CUSPARSE_INDEX_BASE_ZERO = 0
CUSPARSE_INDEX_BASE_ONE = 1

# Operation types:
CUSPARSE_OPERATION_NON_TRANSPOSE = 0
CUSPARSE_OPERATION_TRANSPOSE = 1
CUSPARSE_OPERATION_CONJUGATE_TRANSPOSE = 2

# Whether or not to parse elements of a dense matrix row or column-wise.
CUSPARSE_DIRECTION_ROW = 0
CUSPARSE_DIRECTION_COLUMN = 1

# Action data type
CUSPARSE_ACTION_SYMBOLIC = 0
CUSPARSE_ACTION_NUMERIC = 1

# Helper functions:
class cusparseMatDescr(ctypes.Structure):
    _fields_ = [
        ('MatrixType', ctypes.c_int),
        ('FillMode', ctypes.c_int),
        ('DiagType', ctypes.c_int),
        ('IndexBase', ctypes.c_int)
        ]

def cusparseCheckStatus(status):
    """
    Raise CUSPARSE exception

    Raise an exception corresponding to the specified CUSPARSE error
    code.

    Parameters
    ----------
    status : int
        CUSPARSE error code.

    See Also
    --------
    cusparseExceptions

    """

    if status != 0:
        try:
            raise cusparseExceptions[status]
        except KeyError:
            raise cusparseError

_libcusparse.cusparseCreate.restype = int
_libcusparse.cusparseCreate.argtypes = [ctypes.c_void_p]

def cusparseCreate():
    """
    Initialize CUSPARSE.

    Initializes CUSPARSE and creates a handle to a structure holding
    the CUSPARSE library context.

    Returns
    -------
    handle : int
        CUSPARSE library context.

    """

    handle = ctypes.c_int()
    status = _libcusparse.cusparseCreate(ctypes.byref(handle))
    cusparseCheckStatus(status)
    return handle.value


_libcusparse.cusparseCreateSolveAnalysisInfo.restype = int
_libcusparse.cusparseCreateSolveAnalysisInfo.argtypes = [ctypes.c_void_p]

def cusparseCreateSolveAnalysisInfo():
    """
    Initialize analysis info.

    Initializes CUSPARSE and creates a info to a structure holding
    the CUDAarray.

    Returns
    -------
    info : int

    """

    info = ctypes.c_int()
    status = _libcusparse.cusparseCreateSolveAnalysisInfo(ctypes.byref(info))
    cusparseCheckStatus(status)
    return info

_libcusparse.cusparseDestroy.restype = int
_libcusparse.cusparseDestroy.argtypes = [ctypes.c_void_p]

def cusparseDestroy(handle):
    """
    Release CUSPARSE resources.

    Releases hardware resources used by CUSPARSE

    Parameters
    ----------
    handle : int
        CUSPARSE library context.

    """

    status = _libcusparse.cusparseDestroy(handle)
    cusparseCheckStatus(status)

_libcusparse.cusparseGetVersion.restype = int
_libcusparse.cusparseGetVersion.argtypes = [ctypes.c_int,
                                            ctypes.c_void_p]
def cusparseGetVersion(handle):
    """
    Return CUSPARSE library version.

    Returns the version number of the CUSPARSE library.

    Parameters
    ----------
    handle : int
        CUSPARSE library context.

    Returns
    -------
    version : int
        CUSPARSE library version number.

    """

    version = ctypes.c_int()
    status = _libcusparse.cusparseGetVersion(handle,
                                             ctypes.byref(version))
    cusparseCheckStatus(status)
    return version.value

_libcusparse.cusparseSetStream.restype = int
_libcusparse.cusparseSetStream.argtypes = [ctypes.c_int,
                                                 ctypes.c_int]
def cusparseSetStream(handle, id):
    """
    Sets the CUSPARSE stream in which kernels will run.

    Parameters
    ----------
    handle : int
        CUSPARSE library context.
    id : int
        Stream ID.

    """

    status = _libcusparse.cusparseSetStream(handle, id)
    cusparseCheckStatus(status)

_libcusparse.cusparseCreateMatDescr.restype = int
_libcusparse.cusparseCreateMatDescr.argtypes = [ctypes.POINTER(cusparseMatDescr)]

def cusparseCreateMatDescr():
    """
    Initialize a sparse matrix descriptor.

    Initializes the `MatrixType` and `IndexBase` fields of the matrix
    descriptor to the default values `CUSPARSE_MATRIX_TYPE_GENERAL`
    and `CUSPARSE_INDEX_BASE_ZERO`.

    Returns
    -------
    desc : cusparseMatDescr
        Matrix descriptor.

    """
    desc = cusparseMatDescr()
    status = _libcusparse.cusparseCreateMatDescr(ctypes.byref(desc))
    cusparseCheckStatus(status)
    desc.MatrixType = 0
    desc.IndexBase = 0
    return desc

_libcusparse.cusparseDestroyMatDescr.restype = int
_libcusparse.cusparseDestroyMatDescr.argtypes = [ctypes.c_int]

def cusparseDestroyMatDescr(desc):
    """
    Releases the memory allocated for the matrix descriptor.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.

    """

    status = _libcusparse.cusparseDestroyMatDescr(desc)
    cusparseCheckStatus(status)

_libcusparse.cusparseSetMatType.argtypes = [cusparseMatDescr,
                                            ctypes.c_int]
def cusparseSetMatType(desc, type):
    """
    Sets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.
    type : int
        Matrix type.

    """
    desc.MatrixType = type
    return desc

def cusparseGetMatType(desc):
    """
    Gets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.

    Returns
    -------
    type : int
        Matrix type.

    """

    return desc.MatrixType

def cusparseSetMatFillMode(desc, type):
    """
    Sets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.
    type : int
        Fill mode.

    """
    desc.FillMode = type
    return desc


def cusparseGetMatFillMode(desc):
    """
    Gets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.

    Returns
    -------
    type : int
        Fill mode.

    """

    return desc.FillMode

def cusparseSetMatDiagType(desc, type):
    """
    Sets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.
    type : int
        Diagonal type.

    """
    desc.DiagType = type
    return desc

def cusparseGetMatDiagType(desc):
    """
    Gets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.

    Returns
    -------
    type : int
        Diagonal type.

    """
    return desc.DiagType

def cusparseSetMatIndexBase(desc, type):
    """
    Sets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.
    type : int
        Index base type.

    """
    desc.IndexBase = type
    return desc

def cusparseGetMatIndexBase(desc):
    """
    Gets the matrix type of the specified matrix.

    Parameters
    ----------
    desc : cusparseMatDescr
        Matrix descriptor.

    Returns
    -------
    type : int
        Index base type.

    """

    return desc.IndexBase

# Extra:
_libcusparse.cusparseXcsrgemmNnz.restype = int
_libcusparse.cusparseXcsrgemmNnz.argtypes = [ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_void_p,
                                          ctypes.c_void_p]

def cusparseXcsrgemmNnz(handle, transA, transB, m, n, k, descrA, nnzA, csrRowPtrA, csrColIndA, descrB, nnzB, csrRowPtrB, csrColIndB, descrC, csrRowPtrC):
    dcsrRowPtrA = gpuarray.to_gpu(csrRowPtrA)
    dcsrColIndA = gpuarray.to_gpu(csrColIndA)
    dcsrRowPtrB = gpuarray.to_gpu(csrRowPtrB)
    dcsrColIndB = gpuarray.to_gpu(csrColIndB)
    dcsrRowPtrC = gpuarray.to_gpu(csrRowPtrC)
    nnzTotalDevHostPtr = ctypes.c_int()
    status = _libcusparse.cusparseXcsrgemmNnz(handle, transA, transB, m, n, k, descrA, nnzA, int(dcsrRowPtrA.gpudata), int(dcsrColIndA.gpudata), descrB, nnzB, int(dcsrRowPtrB.gpudata), int(dcsrColIndB.gpudata), descrC, int(dcsrRowPtrC.gpudata), ctypes.byref(nnzTotalDevHostPtr))
    cusparseCheckStatus(status)

    csrRowPtrC = dcsrRowPtrC.get()
    return csrRowPtrC, nnzTotalDevHostPtr


_libcusparse.cusparseDcsrgemm.restype = int
_libcusparse.cusparseDcsrgemm.argtypes = [ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p]

def cusparseDcsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, csrValA, csrRowPtrA, csrColIndA, descrB, nnzB, csrValB, csrRowPtrB, csrColIndB, descrC, csrValC, csrRowPtrC, csrColIndC):

    """
    Matrix(csr)-matrix(csr) product
    """
    dcsrValA = gpuarray.to_gpu(csrValA)
    dcsrRowPtrA = gpuarray.to_gpu(csrRowPtrA)
    dcsrColIndA = gpuarray.to_gpu(csrColIndA)
    dcsrValB = gpuarray.to_gpu(csrValB)
    dcsrRowPtrB = gpuarray.to_gpu(csrRowPtrB)
    dcsrColIndB = gpuarray.to_gpu(csrColIndB)
    dcsrValC = gpuarray.to_gpu(csrValC)
    dcsrRowPtrC = gpuarray.to_gpu(csrRowPtrC)
    dcsrColIndC = gpuarray.to_gpu(csrColIndC)

    status = _libcusparse.cusparseDcsrgemm(handle, transA, transB, m, n, k, ctypes.byref(descrA), nnzA, int(dcsrValA.gpudata), int(dcsrRowPtrA.gpudata), int(dcsrColIndA.gpudata), ctypes.byref(descrB), nnzB, int(dcsrValB.gpudata), int(dcsrRowPtrB.gpudata), int(dcsrColIndB.gpudata), ctypes.byref(descrC), int(dcsrValC.gpudata), int(dcsrRowPtrC.gpudata), int(dcsrColIndC.gpudata))
    cusparseCheckStatus(status)

    csrValC = dcsrValC.get()
    csrRowPtrC = dcsrRowPtrC.get()
    csrColIndC = dcsrColIndC.get()
    return csrValC, csrRowPtrC, csrColIndC

_libcusparse.cusparseScsrgemm.restype = int
_libcusparse.cusparseScsrgemm.argtypes = [ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p]

def cusparseScsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, csrValA, csrRowPtrA, csrColIndA, descrB, nnzB, csrValB, csrRowPtrB, csrColIndB, descrC, csrValC, csrRowPtrC, csrColIndC):

    """
    Matrix(csr)-matrix(csr) product
    """
    dcsrValA = gpuarray.to_gpu(csrValA)
    dcsrRowPtrA = gpuarray.to_gpu(csrRowPtrA)
    dcsrColIndA = gpuarray.to_gpu(csrColIndA)
    dcsrValB = gpuarray.to_gpu(csrValB)
    dcsrRowPtrB = gpuarray.to_gpu(csrRowPtrB)
    dcsrColIndB = gpuarray.to_gpu(csrColIndB)
    dcsrValC = gpuarray.to_gpu(csrValC)
    dcsrRowPtrC = gpuarray.to_gpu(csrRowPtrC)
    dcsrColIndC = gpuarray.to_gpu(csrColIndC)

    status = _libcusparse.cusparseScsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, int(dcsrValA.gpudata), int(dcsrRowPtrA.gpudata), int(dcsrColIndA.gpudata), descrB, nnzB, int(dcsrValB.gpudata), int(dcsrRowPtrB.gpudata), int(dcsrColIndB.gpudata), descrC, int(dcsrValC.gpudata), int(dcsrRowPtrC.gpudata), int(dcsrColIndC.gpudata))
    cusparseCheckStatus(status)

    csrValC = dcsrValC.get()
    csrRowPtrC = dcsrRowPtrC.get()
    csrColIndC = dcsrColIndC.get()
    return csrValC, csrRowPtrC, csrColIndC

_libcusparse.cusparseCcsrgemm.restype = int
_libcusparse.cusparseCcsrgemm.argtypes = [ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p]

def cusparseCcsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, csrValA, csrRowPtrA, csrColIndA, descrB, nnzB, csrValB, csrRowPtrB, csrColIndB, descrC, csrValC, csrRowPtrC, csrColIndC):

    """
    Matrix(csr)-matrix(csr) product
    """
    dcsrValA = gpuarray.to_gpu(csrValA)
    dcsrRowPtrA = gpuarray.to_gpu(csrRowPtrA)
    dcsrColIndA = gpuarray.to_gpu(csrColIndA)
    dcsrValB = gpuarray.to_gpu(csrValB)
    dcsrRowPtrB = gpuarray.to_gpu(csrRowPtrB)
    dcsrColIndB = gpuarray.to_gpu(csrColIndB)
    dcsrValC = gpuarray.to_gpu(csrValC)
    dcsrRowPtrC = gpuarray.to_gpu(csrRowPtrC)
    dcsrColIndC = gpuarray.to_gpu(csrColIndC)

    status = _libcusparse.cusparseCcsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, int(dcsrValA.gpudata), int(dcsrRowPtrA.gpudata), int(dcsrColIndA.gpudata), descrB, nnzB, int(dcsrValB.gpudata), int(dcsrRowPtrB.gpudata), int(dcsrColIndB.gpudata), descrC, int(dcsrValC.gpudata), int(dcsrRowPtrC.gpudata), int(dcsrColIndC.gpudata))
    cusparseCheckStatus(status)

    csrValC = dcsrValC.get()
    csrRowPtrC = dcsrRowPtrC.get()
    csrColIndC = dcsrColIndC.get()
    return csrValC, csrRowPtrC, csrColIndC

_libcusparse.cusparseZcsrgemm.restype = int
_libcusparse.cusparseZcsrgemm.argtypes = [ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.c_int,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_int,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.POINTER(cusparseMatDescr),
                                          ctypes.c_void_p,
                                          ctypes.c_void_p,
                                          ctypes.c_void_p]

def cusparseZcsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, csrValA, csrRowPtrA, csrColIndA, descrB, nnzB, csrValB, csrRowPtrB, csrColIndB, descrC, csrValC, csrRowPtrC, csrColIndC):

    """
    Matrix(csr)-matrix(csr) product
    """
    dcsrValA = gpuarray.to_gpu(csrValA)
    dcsrRowPtrA = gpuarray.to_gpu(csrRowPtrA)
    dcsrColIndA = gpuarray.to_gpu(csrColIndA)
    dcsrValB = gpuarray.to_gpu(csrValB)
    dcsrRowPtrB = gpuarray.to_gpu(csrRowPtrB)
    dcsrColIndB = gpuarray.to_gpu(csrColIndB)
    dcsrValC = gpuarray.to_gpu(csrValC)
    dcsrRowPtrC = gpuarray.to_gpu(csrRowPtrC)
    dcsrColIndC = gpuarray.to_gpu(csrColIndC)

    status = _libcusparse.cusparseZcsrgemm(handle, transA, transB, m, n, k, descrA, nnzA, int(dcsrValA.gpudata), int(dcsrRowPtrA.gpudata), int(dcsrColIndA.gpudata), descrB, nnzB, int(dcsrValB.gpudata), int(dcsrRowPtrB.gpudata), int(dcsrColIndB.gpudata), descrC, int(dcsrValC.gpudata), int(dcsrRowPtrC.gpudata), int(dcsrColIndC.gpudata))
    cusparseCheckStatus(status)

    csrValC = dcsrValC.get()
    csrRowPtrC = dcsrRowPtrC.get()
    csrColIndC = dcsrColIndC.get()
    return csrValC, csrRowPtrC, csrColIndC


_libcusparse.cusparseXcoo2csr.restype = int
_libcusparse.cusparseXcoo2csr.argtypes = [ctypes.c_int,
                                           ctypes.c_void_p,
                                           ctypes.c_int,
                                           ctypes.c_int,
                                           ctypes.c_void_p]

def cusparseXcoo2csr(handle, cooRowPtr, nnz, m, idxBase):
    csrRowPtr = np.zeros(m+1, dtype=np.int32)
    dcooRowPtr = gpuarray.to_gpu(cooRowPtr)
    dcsrRowPtr = gpuarray.to_gpu(csrRowPtr)
    _libcusparse.cusparseXcoo2csr(handle, int(dcooRowPtr.gpudata), nnz, m, int(dcsrRowPtr.gpudata), idxBase)
    csrRowPtr = dcsrRowPtr.get()
    return csrRowPtr

_libcusparse.cusparseXcsr2coo.restype = int
_libcusparse.cusparseXcsr2coo.argtypes = [ctypes.c_int,
                                           ctypes.c_void_p,
                                           ctypes.c_int,
                                           ctypes.c_int,
                                           ctypes.c_void_p]

def cusparseXcsr2coo(handle, csrRowPtr, nnz, m, idxBase):
    cooRowPtr = np.zeros(nnz, dtype=np.int32)
    dcooRowPtr = gpuarray.to_gpu(cooRowPtr)
    dcsrRowPtr = gpuarray.to_gpu(csrRowPtr)
    _libcusparse.cusparseXcsr2coo(handle, int(dcsrRowPtr.gpudata), nnz, m, int(dcooRowPtr.gpudata), idxBase)
    cooRowPtr = dcooRowPtr.get()
    return cooRowPtr

_libcusparse.cusparseDcsr2csc_v2.restype = int
_libcusparse.cusparseDcsr2csc_v2.argtypes = [ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_int,
                                            ctypes.c_int]

def cusparseDcsrcsc_v2(handle, m, n, nnz, csrVal, csrRowPtr, csrColInd, cscVal, cscRowInd, cscColPtr, copyValues, idxBase = 0):

    dcsrVal = gpuarray.to_gpu(csrVal)
    dcsrRowPtr = gpuarray.to_gpu(csrRowPtr)
    dcsrColInd = gpuarray.to_gpu(csrColInd)
    dcscVal = gpuarray.to_gpu(cscVal)
    dcscRowPtr = gpuarray.to_gpu(cscRowPtr)
    dcscColInd = gpuarray.to_gpu(cscColInd)

    _libcusparse.cusparseDcsrcsc_v2(handle, m, n, nnz, int(dcsrVal.gpudata), int(dcsrRowPtr.goudata), int(dcsrColInd.gpudata), int(dcscVal.gpudata), int(dcscRowInd.gpudata), int(dcscColPtr.gpudata), copyValues, idxBase)

    cscVal = dcscVal.get()
    cscRowInd = dcscRowInd.get()
    cscColPtr = dcscColPtr.get()
    return cscVal, cscRowInd, cscColPtr



_libcusparse.cusparseScsrsv_analysis.restype = int
_libcusparse.cusparseScsrsv_analysis.argtypes = [ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.POINTER(cusparseMatDescr),
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_int]

def cusparseScsrsv_analysis(handle, transA, m, nnz, descrA, csrVal, csrRowPtr, csrColInd, info):

    #dcsrVal = gpuarray.to_gpu(csrVal)
    #dcsrRowPtr = gpuarray.to_gpu(csrRowPtr)
    #dcsrColInd = gpuarray.to_gpu(csrColInd)

    #status = _libcusparse.cusparseScsrsv_analysis(handle, transA, m, nnz, descrA, int(dcsrVal.gpudata), int(dcsrRowPtr.gpudata), int(dcsrColInd.gpudata), info)
    status = _libcusparse.cusparseScsrsv_analysis(handle, transA, m, nnz, descrA, int(csrVal), csrRowPtr, csrColInd, info)
    cusparseCheckStatus(status)

    return info



_libcusparse.cusparseScsrsv_solve.restype = int
_libcusparse.cusparseScsrsv_solve.argtypes = [ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_int,
                                            ctypes.c_float,
                                            ctypes.POINTER(cusparseMatDescr),
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p,
                                            ctypes.c_int,
                                            ctypes.c_void_p,
                                            ctypes.c_void_p]

def cusparseScsrsv_solve(handle, transA, m, alpha, descrA, csrVal, csrRowPtr, csrColInd, info, x, y):
    # solve y from A * y = alpha * x
    #
    # A is a m*m matrix

    dcsrVal = gpuarray.to_gpu(csrVal)
    dcsrRowPtr = gpuarray.to_gpu(csrRowPtr)
    dcsrColInd = gpuarray.to_gpu(csrColInd)

    gpu_x = gpuarray.to_gpu(x)
    gpu_y = gpuarray.to_gpu(y)

    status = _libcusparse.cusparseScsrsv_solve(handle, transA, m, alpha, descrA, int(dcsrVal.gpudata), int(dcsrRowPtr.gpudata), int(dcsrColInd.gpudata), info, int(gpu_x.gpudata), int(gpu_y.gpudata))
    cusparseCheckStatus(status)
    y = gpu_y.get()

    return y


