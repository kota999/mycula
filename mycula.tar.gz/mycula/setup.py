from distutils.core import setup
from distutils.sysconfig import get_python_lib

#install directory of mycula library files (.so, .o)
# if your install directory was changed, need replace ./lib/ to YOUR_DIR
#default dir is ./lib/
LIB_DIR = './lib/'

setup( name = 'mycula',
        version = '1.0',
        description = 'Wrapper of CULA for my study',
        author = 'Kota Natsume',
        author_email = 'natsume-kota@ynu.jp',
        packages = ['mycula'],
        data_files = [(get_python_lib() + '/mycula/lib',
            [LIB_DIR+'cula_solo.so', LIB_DIR+'cula_DC.so',
                LIB_DIR+'cula_DC_host.so', LIB_DIR+'pcula.so'])]
        )
