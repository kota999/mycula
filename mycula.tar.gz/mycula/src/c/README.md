# cublas and cula C sources
# generate shared library from these source
#
# cula_solo.c is cula and cublas functions binding
# data max size is GPU-memory size
# (C2075's memory size is 5GB)
#
# pcula.c is pCULA functions binding
# data max size is GPU-memory size
#
# culaDChost.c is divide conqure functions binding
# feature
# 1. use culaD function (cula simple useage)
# 2. divide conqure (potrf, trtri, trmv)
# 3. multi-GPU (potrf, trtri)
# 4. python code is little
# good useage, but need to take care of stack memory
# recommed small matrix, row ~ 25000 !!
#
#
