//{{{ header files
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<sys/time.h>
#include<cuda.h>
#include<cuda_runtime.h>
#include<cuda_runtime_api.h>
#include<cublas.h>
#include<cublas_v2.h>
#include<cublas_api.h>
#include<cula.h>
#include<cula_device.h>
#include<cula_status.h>
#include<cula_lapack.h>
#include<cula_lapack_device.h>
#include<cula_blas.h>
#include<omp.h>
//}}}

//{{{ utility
inline double get_dtime(void)
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return ((double)(tv.tv_sec)+(double)(tv.tv_usec)*0.001*0.001);
}

void print_tile(double *tile, int npix,int index)
{
    int i, j;
    printf("print tile matrix %d\n", index);
    for(i=0;i<npix;i++)
    {
        for(j=0;j<npix;j++)
        {
            printf("%f ", tile[npix*i + j]);
        }
        printf("\n");
    }
}

int get_sch_len(int divide)
{
    int i, len = 0;
    if(divide == 1) len = 1;
    else for(i=0;i<divide/2;i++) len += 2*(i+1)*(divide-i);
    return len;
}

void checkStatus(culaStatus status, const char* funcname)
{
    if (!status)
        return;

    if(status == culaArgumentError) printf("%s Invalid value for parameter %d\n",funcname,culaGetErrorInfo());
    else if(status == culaDataError) printf("cula %s Data error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaBlasError) printf("cublas %s error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaRuntimeError) printf("cula %s Runtime error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaNotInitialized) printf("culaNotInitialized\n");
    else if(status == culaNoHardware) printf("culaNoHardware\n");
    else if(status == culaInsufficientRuntime) printf("culaInsufficientRuntime\n");
    else if(status == culaInsufficientComputeCapability) printf("culaInsufficientComputeCapability\n");
    else if(status == culaInsufficientMemory) printf("culaInsufficientMemory\n");
    else if(status == culaFeatureNotImplemented) printf("culaFeatureNotImplemented\n");
    else printf("%s\n",culaGetStatusString(status));
    culaShutdown();
    exit(EXIT_FAILURE);
}
//}}}

//{{{ divide conquer
void potrf(double *cov, int npix, int divide, bool p_option)
{
    int i, j, k, npix2;
    double d0,d1;
    culaStatus status;
    npix2 = npix*npix;
    if(p_option) printf("divide = %d\n", divide);
    if(p_option) printf("npix = %d\n", npix);
    if(p_option) printf("matrix pix = %d * %d\n", divide*npix, divide*npix);
    /*d0 = get_dtime();*/
    /*read_tile_matrix( tile, npix, divide);*/
    /*d1 = get_dtime();*/
    /*if(p_option) printf("load matrix = %lf sec\n",d1-d0);*/

    d0 = get_dtime();
    for(i=0;i<divide;i++)
        {
          status = culaDpotrf('L',npix,&cov[(divide*i+i)*npix2],npix);
          checkStatus(status, "culaDpotrf");
          if(p_option) printf("POTRF[%d][%d]  | Ap[%d][%d]\n",i,i,i,i);
          cudaThreadSynchronize();
          for(j=i+1;j<divide;j++)
            {
              status = culaDtrsm('R','L','T','N',npix,npix,1.0,&cov[(divide*i+i)*npix2],npix,&cov[(divide*i+j)*npix2],npix);
              checkStatus(status, "culaDtrsm");
              if(p_option) printf("TRSM[%d][%d]   | Ap[%d][%d],Bp[%d][%d]\n",i,j,i,i,i,j);
              cudaThreadSynchronize();
            }
          for(j=i+1;j<divide;j++)
            {
              status = culaDsyrk('L','N',npix,npix,-1.0,&cov[(divide*i+j)*npix2],npix,1.0,&cov[(divide*j+j)*npix2],npix);
              checkStatus(status, "culaDsyrk");
              if(p_option) printf("SYRK[%d][%d]   | Ap[%d][%d],Bp[%d][%d]\n",j,j,j,j,i,j);
              cudaThreadSynchronize();
            }
          for(j=i+1;j<divide-1;j++)
            {
              for(k=j+1;k<divide;k++)
                {
                   status = culaDgemm('N','T',npix,npix,npix,-1.0,&cov[(divide*i+k)*npix2],npix,&cov[(divide*i+j)*npix2],npix,1.0,&cov[(divide*j+k)*npix2],npix);
                   checkStatus(status, "culaDgemm");
                  if(p_option) printf("GEMM[%d][%d]   | Ap[%d][%d],Bp[%d][%d],Cp[%d][%d]\n",j,k,j,k,i,k,i,j);
                }
            }
        }
    d1 = get_dtime();
    if(p_option) printf("finish culaDpotrf by divide conquer = %lf sec\n",d1-d0);
}

void trtri(double *cov, int npix, int divide, bool p_option)
{
    // single pointer
    // use lower function option
    int i, j, k, npix2;
    npix2 = npix*npix;
    double d0,d1;
    culaStatus status;
    printf("divide = %d\n", divide);
    printf("npix = %d\n", npix);
    printf("matrix pix = %d * %d\n", divide*npix, divide*npix);
    size_t size = npix*npix*sizeof(double);
    for(i=0;i<divide;i++)
    {
        for(j=i+1;j<divide;j++)
        {
            cudaMemcpy(&cov[(divide*j+i)*npix2],&cov[(divide*i+j)*npix2],size,cudaMemcpyHostToHost);
        }
    }
    /*d0 = get_dtime();*/
    /*read_tile_matrix( tile, npix, divide);*/
    /*d1 = get_dtime();*/
    /*if(p_option) printf("load matrix = %lf sec\n",d1-d0);*/
    d0 = get_dtime();
    for(i=0;i<divide;i++)
    {
        status = culaDtrtri('L','N', npix, &cov[(divide*i+i)*npix2], npix);
        checkStatus(status, "culaDtrtri");
        if(p_option) printf("TRTRI[%d][%d]  | Ap[%d][%d]\n", i, i, i, i);
    }
    for(i=0;i<divide;i++)
    {
        for(j=i+1;j<divide;j++)
        {
            status = culaDtrmm('R','L','N','N', npix, npix, -1.0, &cov[(divide*i+i)*npix2], npix, &cov[(divide*i+j)*npix2], npix);
            checkStatus(status, "culaDtrmm");
            if(p_option) printf("TRMMR[%d][%d]  | Ap[%d][%d],Bp[%d][%d]\n", i, j, i, j, i, i);
        }
    }
    for(i=1;i<divide;i++)
    {
        for(j=0;j+i<divide;j++)
        {
            status = culaDtrmm('L','L','N','N', npix, npix, 1.0, &cov[(divide*(j+i)+j+i)*npix2], npix, &cov[(divide*j+j+i)*npix2], npix);
            checkStatus(status, "culaDtrmm");
            if(p_option) printf("TRMML[%d][%d]  | Ap[%d][%d],Bp[%d][%d]\n", j, j+i, j+i, j+i, j, j+i);
        }
        for(j=0;j+i<divide;j++)
        {
            for(k=j+i+1;k<divide;k++)
            {
                status = culaDgemm('N','N', npix, npix, npix, -1.0, &cov[(divide*k+j+i)*npix2], npix, &cov[(divide*j+j+i)*npix2], npix, 1.0, &cov[(divide*j+k)*npix2], npix);
                checkStatus(status, "culaDgemm");
                if(p_option) printf("GEMM[%d][%d]   | Ap[%d][%d], Bp_U[%d][%d], Cp[%d][%d]\n", j, k, j, k, j+i, k, j, j+i);
            }
        }
    }
    d1 = get_dtime();
    if(p_option) printf("finish culaDtrtri by divide conquer = %lf sec\n",d1-d0);
}
void trmv(double *tile,double *x, int npix, int divide, char uplo, char transa, char diag)
{
    int i,j,npix2;
    double alpha = 1.0, beta = 1.0;
    npix2 = npix*npix;
    double *dx, *dL;
    cublasAlloc( npix*npix, sizeof(double), (void**)&dL);
    cublasAlloc( npix, sizeof(double), (void**)&dx);
    double **x_sprit = (double**)malloc(divide*sizeof(double*));
    double **y_sprit = (double**)malloc(divide*sizeof(double*));
    for(i=0;i<divide;i++)
    {
        cudaMallocHost((void**)&x_sprit[i],npix*sizeof(double));
        cudaMallocHost((void**)&y_sprit[i],npix*sizeof(double));
        for(j=0;j<npix;j++)
        {
            x_sprit[i][j] = x[npix*i+j];
        }
    }
    cublasHandle_t handle;
    cublasCreate_v2(&handle);
    cublasOperation_t u, t, d;
    if(uplo == 'L') u = CUBLAS_FILL_MODE_LOWER;
    else if(uplo == 'U') u = CUBLAS_FILL_MODE_UPPER;
    if(transa == 'N') t = CUBLAS_OP_N;
    else if(transa == 'T') t = CUBLAS_OP_T;
    else if(transa == 'C') t = CUBLAS_OP_C;
    if(diag == 'N') d = CUBLAS_DIAG_NON_UNIT;
    else if(diag == 'U') d = CUBLAS_DIAG_UNIT;

    for(i=0;i<divide;i++)
    {
        cudaMemcpy(dL,&tile[(divide*i+i)*npix2],npix2*sizeof(double),cudaMemcpyHostToDevice);
        cudaMemcpy(dx,x_sprit[i],npix*sizeof(double),cudaMemcpyHostToDevice);
        /*cublasDtrmv_v2( handle,CUBLAS_FILL_MODE_LOWER,CUBLAS_OP_N,CUBLAS_DIAG_NON_UNIT, npix, dL, npix, dx, 1);*/
        cublasDtrmv_v2( handle,u,t,d, npix, dL, npix, dx, 1);
        /*y <- L*x + y */
        cudaMemcpy(y_sprit[i],dx,npix*sizeof(double),cudaMemcpyDeviceToHost);
    }
    /*for(i=0;i<divide;i++) for(j=0;j<npix;j++) printf("%lf ",y_sprit[i][j]);*/

    for(i=0;i<divide;i++)
    {
        for(j=i+1;j<divide;j++)
        {
            culaDgemv( 'N', npix, npix, alpha, &tile[(divide*i+j)*npix2], npix, x_sprit[i], 1, beta, y_sprit[j], 1);
            /*y <- A*x + y */
        }
    }

    for(i=0;i<divide;i++)
    {
        for(j=0;j<npix;j++)
        {
            x[npix*i+j] =  y_sprit[i][j];
        }
    }

    cublasFree(dL);
    cublasFree(dx);
    for(i=0;i<divide;i++);
    {
        cudaFreeHost(x_sprit[i]);
        cudaFreeHost(y_sprit[i]);
        cublasDestroy_v2(handle);
    }
}
//}}}

//{{{ set algorithm
void set_potrf_alg(int **sch, int divide, int ngpu, bool p_option)
{
    int i, j, k, row, col = 0, len = 0;
    len = get_sch_len( divide);

    for(i=0;i<divide;i++)
    {
        row = 0;
        sch[ngpu*col + row][0] = 1; // mean of 1 is potrf
        sch[ngpu*col + row][1] = divide*i + i;
        if(p_option) printf("potrf : %d , %d \n", sch[ngpu*col + row][0], sch[ngpu*col + row][1]);
        col += 1;
        row = 0;
        for(j=i+1;j<divide;j++)
        {
            sch[ngpu*col + row][0] = 2; // mean of 2 is trsm
            sch[ngpu*col + row][1] = divide*i + i;
            sch[ngpu*col + row][2] = divide*i + j;
            if(p_option) printf("trsm : %d , %d %d\n", sch[ngpu*col + row][0], sch[ngpu*col + row][1], sch[ngpu*col + row][2]);
            row += 1;
            if(row == ngpu)
            {
                row = 0;
                col += 1;
            }
        }
        if(row!=0) col += 1;
        row = 0;
        for(j=i+1;j<divide;j++)
        {
            sch[ngpu*col + row][0] = 3; // mean of 3 is syrk
            sch[ngpu*col + row][1] = divide*j + j;
            sch[ngpu*col + row][2] = divide*i + j;
            if(p_option) printf("syrk : %d , %d %d\n", sch[ngpu*col + row][0], sch[ngpu*col + row][1], sch[ngpu*col + row][2]);
            row += 1;
            if(row == ngpu)
            {
                row = 0;
                col += 1;
            }
        }
        for(j=i+1;j<divide-1;j++)
        {
            for(k=j+1;k<divide;k++)
            {
                sch[ngpu*col + row][0] = 4; // mean of 4 is gemm
                sch[ngpu*col + row][1] = divide*i + k;
                sch[ngpu*col + row][2] = divide*i + j;
                sch[ngpu*col + row][3] = divide*j + k;
                if(p_option) printf("gemm : %d , %d %d %d\n", sch[ngpu*col + row][0], sch[ngpu*col + row][1], sch[ngpu*col + row][2], sch[ngpu*col + row][3]);
                row += 1;
                if(row == ngpu)
                {
                    row = 0;
                    col += 1;
                }
            }
        }
        if(row!=0) col += 1;
        row = 0;
    }
    if(p_option)
    {
       for(i=0;i<len;i++)
        {
            for(j=0;j<ngpu;j++)
            {
                printf(" gpu %d, cal %d", j, sch[ngpu*i + j][0]);
            }
            printf("\n");
        }
    }
}

void set_trtri_alg(int **sch, int divide, int ngpu, bool p_option)
{
    int i, j, k, row, col = 0, len = 0;
    len = get_sch_len( divide);
    row = 0;
    for(i=0;i<divide;i++)
    {
        sch[ngpu*col + row][0] = 5; // mean of 5 is trtri
        sch[ngpu*col + row][1] = divide*i + i;
        if(p_option) printf("trtri : %d , %d \n", sch[ngpu*col + row][0], sch[ngpu*col + row][1]);
        row += 1;
        if(row == ngpu)
        {
            row = 0;
            col += 1;
        }
    }
    if(row!=0) col += 1;
    row = 0;
    for(i=0;i<divide;i++)
    {
        for(j=i+1;j<divide;j++)
        {
            sch[ngpu*col + row][0] = 6; // mean of 6 is trmmr
            sch[ngpu*col + row][1] = divide*i + i;
            sch[ngpu*col + row][2] = divide*i + j;
            if(p_option) printf("trmmr : %d , %d %d\n", sch[ngpu*col + row][0], sch[ngpu*col + row][1], sch[ngpu*col + row][2]);
            row += 1;
            if(row == ngpu)
            {
                row = 0;
                col += 1;
            }
        }
    }
    if(row!=0) col += 1;
    row = 0;
    for(i=1;i<divide;i++)
    {
        row = 0;
        for(j=0;j+i<divide;j++)
        {
            sch[ngpu*col + row][0] = 7; // mean of 7 is trmml
            sch[ngpu*col + row][1] = divide*(j+i) + j + i;
            sch[ngpu*col + row][2] = divide*j + j + i;
            if(p_option) printf("trmml : %d , %d %d\n", sch[ngpu*col + row][0], sch[ngpu*col + row][1], sch[ngpu*col + row][2]);
            row += 1;
            if(row == ngpu)
            {
                row = 0;
                col += 1;
            }
        }
        if(row!=0) col += 1;
        row = 0;
        for(j=0;j+i<divide;j++)
        {
            for(k=j+i+1;k<divide;k++)
            {
                sch[ngpu*col + row][0] = 8; // mean of 8 is gemm nn
                sch[ngpu*col + row][1] = divide*k + j + i;
                sch[ngpu*col + row][2] = divide*j + j + i;
                sch[ngpu*col + row][3] = divide*j + k;
                if(p_option) printf("gemm : %d , %d %d %d\n", sch[ngpu*col + row][0], sch[ngpu*col + row][1], sch[ngpu*col + row][2], sch[ngpu*col + row][3]);
                row += 1;
                if(row == ngpu)
                {
                    row = 0;
                    col += 1;
                }
            }
        }
        if(row!=0) col += 1;
        row = 0;
    }
    if(p_option)
    {
        for(i=0;i<len;i++)
        {
            for(j=0;j<ngpu;j++)
            {
                printf(" gpu %d, cal %d", j, sch[ngpu*i + j][0]);
            }
            printf("\n");
        }
    }
}
//}}}

//{{{ cal function
void calc(double *tile, int **sch, int npix, int ngpu, int len,bool p_option)
{
    int i, j, npix2;
    culaStatus status;
    npix2 = npix*npix;
    omp_set_num_threads(ngpu);
    for(i=0;i<len;i++)
    {
#pragma omp parallel for
        for(j=0;j<ngpu;j++)
        {
            status = culaSelectDevice(omp_get_thread_num());
            if(sch[ngpu*i+j][0] == 1)
            {
                status = culaDpotrf('L', npix, &tile[(sch[ngpu*i+j][1])*npix2], npix);
                checkStatus(status, "culaDpotrf");
                if(p_option) printf("potrf\n");
            }
            else if(sch[ngpu*i+j][0] == 2)
            {
                status = culaDtrsm('R','L','T','N',npix,npix,1.0,&tile[(sch[ngpu*i+j][1])*npix2],npix,&tile[(sch[ngpu*i+j][2])*npix2],npix);
                checkStatus(status, "culaDtrsm");
                if(p_option) printf("trsm\n");
            }
            else if(sch[ngpu*i+j][0] == 3)
            {
                status = culaDsyrk('L','N',npix,npix,-1.0,&tile[(sch[ngpu*i+j][2])*npix2],npix,1.0,&tile[(sch[ngpu*i+j][1])*npix2],npix);
                checkStatus(status, "culaDsyrk");
                if(p_option) printf("syrk\n");
            }
            else if(sch[ngpu*i+j][0] == 4)
            {
                status = culaDgemm('N','T',npix,npix,npix,-1.0,&tile[(sch[ngpu*i+j][1])*npix2],npix,&tile[(sch[ngpu*i+j][2])*npix2],npix,1.0,&tile[(sch[ngpu*i+j][3])*npix2],npix);
                checkStatus(status, "culaDgemm");
                if(p_option) printf("gemm\n");
            }
            else if(sch[ngpu*i+j][0] == 5)
            {
                status = culaDtrtri('L','N', npix, &tile[(sch[ngpu*i+j][1])*npix2], npix);
                checkStatus(status, "culaDtrtri");
                if(p_option) printf("trtri\n");
            }
            else if(sch[ngpu*i+j][0] == 6)
            {
                status = culaDtrmm('R','L','N','N', npix, npix, -1.0, &tile[(sch[ngpu*i+j][1])*npix2], npix, &tile[(sch[ngpu*i+j][2])*npix2], npix);
                checkStatus(status, "culaDtrmm");
                if(p_option) printf("trmmr\n");
            }
            else if(sch[ngpu*i+j][0] == 7)
            {
                status = culaDtrmm('L','L','N','N', npix, npix, 1.0, &tile[(sch[ngpu*i+j][1])*npix2], npix, &tile[(sch[ngpu*i+j][2])*npix2], npix);
                checkStatus(status, "culaDtrmm");
                if(p_option) printf("trmml\n");
            }
            else if(sch[ngpu*i+j][0] == 8)
            {
                status = culaDgemm('N','N', npix, npix, npix, -1.0, &tile[(sch[ngpu*i+j][1])*npix2], npix, &tile[(sch[ngpu*i+j][2])*npix2], npix, 1.0, &tile[(sch[ngpu*i+j][3])*npix2], npix);
                checkStatus(status, "culaDgemm");
                if(p_option) printf("gemm\n");
            }
        }
    }
}
//}}}

//{{{ parallel cula
void ppotrf(double *cov, int npix, int divide, int ngpu, bool p_option, bool calc_p)
{
    if(p_option) printf("npix = %d , divide = %d , col * row = %d * %d\n", npix, divide, npix*divide, npix*divide);
    if(p_option) printf("ngpu = %d\n", ngpu);
    int i, j, len = 0;
    double d0,d1;
    /*d0 = get_dtime();*/
    /*read_tile_matrix( tile, npix, divide);*/
    /*d1 = get_dtime();*/
    /*if(p_option) printf("load matrix = %lf sec\n",d1-d0);*/

    len = get_sch_len( divide);
    int **sch = (int**)malloc(len*ngpu*sizeof(int*));
    for(i=0;i<len*ngpu;i++) cudaMallocHost((void**)&sch[i], 4*sizeof(int));
    for(i=0;i<len*ngpu;i++)
    {
        for(j=0;j<4;j++) sch[i][j] = 0;
    }
    set_potrf_alg( sch, divide, ngpu, false);
    if(p_option) printf("set algorithm\n");
    d0 = get_dtime();
    calc( cov, sch, npix, ngpu, len, calc_p);
    d1 = get_dtime();
    /*if(p_option)*/
    if(p_option) printf("potrf finished by %d gpu = %lf sec\n",ngpu,d1-d0);
}

void ptrtri(double *cov, int npix, int divide, int ngpu, bool p_option, bool calc_p)
{
    if(p_option) printf("npix = %d , divide = %d , col * row = %d * %d\n", npix, divide, npix*divide, npix*divide);
    if(p_option) printf("ngpu = %d\n", ngpu);
    int i, j, npix2, len = 0;
    npix2 = npix*npix;
    double d0,d1;
    /*d0 = get_dtime();*/
    /*read_tile_matrix( tile, npix, divide);*/
    /*d1 = get_dtime();*/
    /*if(p_option) printf("load matrix = %lf sec\n",d1-d0);*/
    size_t size = npix*npix*sizeof(double);
    for(i=0;i<divide;i++)
    {
        for(j=i+1;j<divide;j++)
        {
            cudaMemcpy(&cov[(divide*j+i)*npix2],&cov[(divide*i+j)*npix2],size,cudaMemcpyHostToHost);
        }
    }
    if(p_option) printf("make memory cash\n");

    len = get_sch_len( divide);
    int **sch = (int**)malloc(len*ngpu*sizeof(int*));
    for(i=0;i<len*ngpu;i++) cudaMallocHost((void**)&sch[i], 4*sizeof(int));
    for(i=0;i<len*ngpu;i++)
    {
        for(j=0;j<4;j++) sch[i][j] = 0;
    }
    set_trtri_alg( sch, divide, ngpu, false);
    if(p_option) printf("set algorithm\n");
    d0 = get_dtime();
    calc( cov, sch, npix, ngpu, len, calc_p);
    d1 = get_dtime();
    /*if(p_option)*/
    if(p_option) printf("trtri finished by %d gpu = %lf sec\n",ngpu,d1-d0);
}
//}}}


// vim: foldmethod=marker
