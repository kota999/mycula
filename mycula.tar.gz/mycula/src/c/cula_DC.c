//{{{ header files
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<sys/time.h>
#include<cuda.h>
#include<cuda_runtime.h>
#include<cuda_runtime_api.h>
#include<cublas.h>
#include<cublas_v2.h>
#include<cublas_api.h>
#include<cula.h>
#include<cula_device.h>
#include<cula_status.h>
#include<cula_lapack.h>
#include<cula_lapack_device.h>
#include<cula_blas.h>
#include<omp.h>
//}}}

//{{{ utility
inline double get_dtime(void)
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return ((double)(tv.tv_sec)+(double)(tv.tv_usec)*0.001*0.001);
}

void print_tile(double *tile, int npix,int index)
{
    int i, j;
    printf("print tile matrix %d\n", index);
    for(i=0;i<npix;i++)
    {
        for(j=0;j<npix;j++)
        {
            printf("%f ", tile[npix*i + j]);
        }
        printf("\n");
    }
}

int get_sch_len(int divide)
{
    int i, len = 0;
    if(divide == 1) len = 1;
    else for(i=0;i<divide/2;i++) len += 2*(i+1)*(divide-i);
    return len;
}
void make_trtri_cash(double *cov, int npix,int divide)
{
    int i,j,npix2;
    npix2 = npix*npix;
    size_t size = npix2*sizeof(double);
    for(i=0;i<divide;i++)
    {
        for(j=i+1;j<divide;j++)
        {
            cudaMemcpy(&cov[(divide*j+i)*npix2],&cov[(divide*i+j)*npix2],size,cudaMemcpyHostToHost);
        }
    }
}
void make_trtri_cash_v2(double *tile1,double *tile2, int npix)
{
    int npix2;
    npix2 = npix*npix;
    size_t size = npix2*sizeof(double);
    cudaMemcpy(tile2,tile1,size,cudaMemcpyHostToHost);
}

void checkStatus(culaStatus status, const char* funcname)
{
    if (!status)
        return;

    if(status == culaArgumentError) printf("%s Invalid value for parameter %d\n",funcname,culaGetErrorInfo());
    else if(status == culaDataError) printf("cula %s Data error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaBlasError) printf("cublas %s error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaRuntimeError) printf("cula %s Runtime error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaNotInitialized) printf("culaNotInitialized\n");
    else if(status == culaNoHardware) printf("culaNoHardware\n");
    else if(status == culaInsufficientRuntime) printf("culaInsufficientRuntime\n");
    else if(status == culaInsufficientComputeCapability) printf("culaInsufficientComputeCapability\n");
    else if(status == culaInsufficientMemory) printf("culaInsufficientMemory\n");
    else if(status == culaFeatureNotImplemented) printf("culaFeatureNotImplemented\n");
    else printf("%s\n",culaGetStatusString(status));
    culaShutdown();
    exit(EXIT_FAILURE);
}
//}}}

//{{{ cal function
void calc(double *tile, int *sch, int index, int npix, int ngpu, bool p_option)
{
    int j, npix2;
    culaStatus status;
    status = culaInitialize();
    checkStatus(status,"Error culaInitialize");
    npix2 = npix*npix;
    omp_set_num_threads(ngpu);
    if(p_option) printf("index = %d\n",index);
#pragma omp parallel for
    for(j=0;j<ngpu;j++)
    {
        status = culaSelectDevice(omp_get_thread_num());
        checkStatus(status,"Error culaSelectDevice");
        status = culaInitialize();
        checkStatus(status,"Error culaInitialize");
        if(sch[(ngpu*index+j)*4+0] == 1)
        {
             if(p_option) printf("potrf\n");
             status = culaDpotrf('L', npix, &tile[(sch[(ngpu*index+j)*4+1])*npix2], npix);

             checkStatus(status,"culaDpotrf");
             cudaThreadSynchronize();
        }
         else if(sch[(ngpu*index+j)*4+0] == 2)
         {
             if(p_option) printf("trsm\n");
             status = culaDtrsm('R','L','T','N',npix,npix,1.0,&tile[(sch[(ngpu*index+j)*4+1])*npix2],npix,&tile[(sch[(ngpu*index+j)*4+2])*npix2],npix);
             checkStatus(status,"culaDtrsm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 3)
         {
             if(p_option) printf("syrk\n");
             status = culaDsyrk('L','N',npix,npix,-1.0,&tile[(sch[(ngpu*index+j)*4+2])*npix2],npix,1.0,&tile[(sch[(ngpu*index+j)*4+1])*npix2],npix);
             checkStatus(status,"culaDsyrk");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 4)
         {
             if(p_option) printf("gemm\n");
             status = culaDgemm('N','T',npix,npix,npix,-1.0,&tile[(sch[(ngpu*index+j)*4+1])*npix2],npix,&tile[(sch[(ngpu*index+j)*4+2])*npix2],npix,1.0,&tile[(sch[(ngpu*index+j)*4+3])*npix2],npix);
             checkStatus(status,"culaDgemm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 5)
         {
             if(p_option) printf("trtri\n");
             status = culaDtrtri('L','N', npix, &tile[(sch[(ngpu*index+j)*4+1])*npix2], npix);
             checkStatus(status,"culaDtrtri");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 6)
         {
             if(p_option) printf("trmmr\n");
             status = culaDtrmm('R','L','N','N', npix, npix, -1.0, &tile[(sch[(ngpu*index+j)*4+1])*npix2], npix, &tile[(sch[(ngpu*index+j)*4+2])*npix2], npix);
             checkStatus(status,"culaDtrmm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 7)
         {
             if(p_option) printf("trmml\n");
             status = culaDtrmm('L','L','N','N', npix, npix, 1.0, &tile[(sch[(ngpu*index+j)*4+1])*npix2], npix, &tile[(sch[(ngpu*index+j)*4+2])*npix2], npix);
             checkStatus(status,"culaDtrmm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 8)
         {
             if(p_option) printf("gemm\n");
             status = culaDgemm('N','N', npix, npix, npix, -1.0, &tile[(sch[(ngpu*index+j)*4+1])*npix2], npix, &tile[(sch[(ngpu*index+j)*4+2])*npix2], npix, 1.0, &tile[(sch[(ngpu*index+j)*4+3])*npix2], npix);
             checkStatus(status,"culaDgemm");
             cudaThreadSynchronize();
         }
     }
    culaFreeBuffers();
    checkStatus(status,"Error culaFreeBuffers");
    culaShutdown();
    checkStatus(status,"Error culaShutdown");
}

void calc_single(double *tileA, double *tileB, double *tileC, int *sch, int index, int npix, int ngpu, bool p_option)
{
    int j, npix2;
    culaStatus s_status;
    s_status = culaInitialize();
    checkStatus(s_status,"Error culaInitialize");
    npix2 = npix*npix;
    if(p_option) printf("index = %d\n",index);
    for(j=0;j<ngpu;j++)
    {
        s_status = culaSelectDevice(omp_get_thread_num());
        checkStatus(s_status,"Error culaSelectDevice");
        s_status = culaInitialize();
        checkStatus(s_status,"Error culaInitialize");
        if(sch[(ngpu*index+j)*4+0] == 1)
        {
             if(p_option) printf("potrf\n");
             s_status = culaDpotrf('L', npix, tileA, npix);

             checkStatus(s_status,"culaDpotrf");
             cudaThreadSynchronize();
        }
         else if(sch[(ngpu*index+j)*4+0] == 2)
         {
             if(p_option) printf("trsm\n");
             s_status = culaDtrsm('R','L','T','N',npix,npix,1.0,tileA,npix,tileB,npix);
             checkStatus(s_status,"culaDtrsm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 3)
         {
             if(p_option) printf("syrk\n");
             s_status = culaDsyrk('L','N',npix,npix,-1.0,tileB,npix,1.0,tileA,npix);
             checkStatus(s_status,"culaDsyrk");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 4)
         {
             if(p_option) printf("gemm\n");
             s_status = culaDgemm('N','T',npix,npix,npix,-1.0,tileA,npix,tileB,npix,1.0,tileC,npix);
             checkStatus(s_status,"culaDgemm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 5)
         {
             if(p_option) printf("trtri\n");
             s_status = culaDtrtri('L','N', npix, tileA, npix);
             checkStatus(s_status,"culaDtrtri");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 6)
         {
             if(p_option) printf("trmmr\n");
             s_status = culaDtrmm('R','L','N','N', npix, npix, -1.0, tileA, npix, tileB, npix);
             checkStatus(s_status,"culaDtrmm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 7)
         {
             if(p_option) printf("trmml\n");
             s_status = culaDtrmm('L','L','N','N', npix, npix, 1.0, tileA, npix, tileB, npix);
             checkStatus(s_status,"culaDtrmm");
             cudaThreadSynchronize();
         }
         else if(sch[(ngpu*index+j)*4+0] == 8)
         {
             if(p_option) printf("gemm\n");
             s_status = culaDgemm('N','N', npix, npix, npix, -1.0, tileA, npix, tileB, npix, 1.0, tileC, npix);
             checkStatus(s_status,"culaDgemm");
             cudaThreadSynchronize();
         }
     }
    culaFreeBuffers();
    checkStatus(s_status,"Error culaFreeBuffers");
    culaShutdown();
    checkStatus(s_status,"Error culaShutdown");
}

void calc_triple(double *tileA0, double *tileB0, double *tileC0,
        double *tileA1, double *tileB1, double *tileC1,
        double *tileA2, double *tileB2, double *tileC2,
        int *sch, int index, int npix, int ngpu, bool p_option)
{
    int j, npix2;
    culaStatus s_status;
    s_status = culaInitialize();
    checkStatus(s_status,"Error culaInitialize");
    npix2 = npix*npix;
    omp_set_num_threads(ngpu);
    if(p_option) printf("index = %d\n",index);
#pragma omp parallel for
    for(j=0;j<ngpu;j++)
    {
        s_status = culaSelectDevice(omp_get_thread_num());
        checkStatus(s_status,"Error culaSelectDevice");
        s_status = culaInitialize();
        checkStatus(s_status,"Error culaInitialize");
        if(sch[(ngpu*index+j)*4+0] == 1)
        {
            if(j == 0)
            {
                if(p_option) printf("potrf\n");
                s_status = culaDpotrf('L', npix, tileA0, npix);
                checkStatus(s_status,"culaDpotrf");
                cudaThreadSynchronize();
            }
            else if(j == 1)
            {
                if(p_option) printf("potrf\n");
                s_status = culaDpotrf('L', npix, tileA1, npix);
                checkStatus(s_status,"culaDpotrf");
                cudaThreadSynchronize();
            }
            else if(j == 2)
            {
                if(p_option) printf("potrf\n");
                s_status = culaDpotrf('L', npix, tileA2, npix);
                checkStatus(s_status,"culaDpotrf");
                cudaThreadSynchronize();
            }
        }
         else if(sch[(ngpu*index+j)*4+0] == 2)
         {
             if(j == 0)
             {
                if(p_option) printf("trsm\n");
                s_status = culaDtrsm('R','L','T','N',npix,npix,1.0,tileA0,npix,tileB0,npix);
                checkStatus(s_status,"culaDtrsm");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("trsm\n");
                s_status = culaDtrsm('R','L','T','N',npix,npix,1.0,tileA1,npix,tileB1,npix);
                checkStatus(s_status,"culaDtrsm");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("trsm\n");
                s_status = culaDtrsm('R','L','T','N',npix,npix,1.0,tileA2,npix,tileB2,npix);
                checkStatus(s_status,"culaDtrsm");
                cudaThreadSynchronize();
             }
         }
         else if(sch[(ngpu*index+j)*4+0] == 3)
         {
             if(j == 0)
             {
                if(p_option) printf("syrk\n");
                s_status = culaDsyrk('L','N',npix,npix,-1.0,tileB0,npix,1.0,tileA0,npix);
                checkStatus(s_status,"culaDsyrk");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("syrk\n");
                s_status = culaDsyrk('L','N',npix,npix,-1.0,tileB1,npix,1.0,tileA1,npix);
                checkStatus(s_status,"culaDsyrk");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("syrk\n");
                s_status = culaDsyrk('L','N',npix,npix,-1.0,tileB2,npix,1.0,tileA2,npix);
                checkStatus(s_status,"culaDsyrk");
                cudaThreadSynchronize();
             }
         }
         else if(sch[(ngpu*index+j)*4+0] == 4)
         {
             if(j == 0)
             {
                if(p_option) printf("gemm\n");
                s_status = culaDgemm('N','T',npix,npix,npix,-1.0,tileA0,npix,tileB0,npix,1.0,tileC0,npix);
                checkStatus(s_status,"culaDgemm");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("gemm\n");
                s_status = culaDgemm('N','T',npix,npix,npix,-1.0,tileA1,npix,tileB1,npix,1.0,tileC1,npix);
                checkStatus(s_status,"culaDgemm");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("gemm\n");
                s_status = culaDgemm('N','T',npix,npix,npix,-1.0,tileA2,npix,tileB2,npix,1.0,tileC2,npix);
                checkStatus(s_status,"culaDgemm");
                cudaThreadSynchronize();
             }
         }
         else if(sch[(ngpu*index+j)*4+0] == 5)
         {
             if(j == 0)
             {
                if(p_option) printf("trtri\n");
                s_status = culaDtrtri('L','N', npix, tileA0, npix);
                checkStatus(s_status,"culaDtrtri");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("trtri\n");
                s_status = culaDtrtri('L','N', npix, tileA1, npix);
                checkStatus(s_status,"culaDtrtri");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("trtri\n");
                s_status = culaDtrtri('L','N', npix, tileA2, npix);
                checkStatus(s_status,"culaDtrtri");
                cudaThreadSynchronize();
             }
         }
         else if(sch[(ngpu*index+j)*4+0] == 6)
         {
             if(j == 0)
             {
                if(p_option) printf("trmmr\n");
                s_status = culaDtrmm('R','L','N','N', npix, npix, -1.0, tileA0, npix, tileB0, npix);
                checkStatus(s_status,"culaDtrmm");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("trmmr\n");
                s_status = culaDtrmm('R','L','N','N', npix, npix, -1.0, tileA1, npix, tileB1, npix);
                checkStatus(s_status,"culaDtrmm");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("trmmr\n");
                s_status = culaDtrmm('R','L','N','N', npix, npix, -1.0, tileA2, npix, tileB2, npix);
                checkStatus(s_status,"culaDtrmm");
                cudaThreadSynchronize();
             }
         }
         else if(sch[(ngpu*index+j)*4+0] == 7)
         {
             if(j == 0)
             {
                if(p_option) printf("trmml\n");
                s_status = culaDtrmm('L','L','N','N', npix, npix, 1.0, tileA0, npix, tileB0, npix);
                checkStatus(s_status,"culaDtrmm");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("trmml\n");
                s_status = culaDtrmm('L','L','N','N', npix, npix, 1.0, tileA1, npix, tileB1, npix);
                checkStatus(s_status,"culaDtrmm");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("trmml\n");
                s_status = culaDtrmm('L','L','N','N', npix, npix, 1.0, tileA2, npix, tileB2, npix);
                checkStatus(s_status,"culaDtrmm");
                cudaThreadSynchronize();
             }
         }
         else if(sch[(ngpu*index+j)*4+0] == 8)
         {
             if(j == 0)
             {
                if(p_option) printf("gemm\n");
                s_status = culaDgemm('N','N', npix, npix, npix, -1.0, tileA0, npix, tileB0, npix, 1.0, tileC0, npix);
                checkStatus(s_status,"culaDgemm");
                cudaThreadSynchronize();
             }
             else if(j == 1)
             {
                if(p_option) printf("gemm\n");
                s_status = culaDgemm('N','N', npix, npix, npix, -1.0, tileA1, npix, tileB1, npix, 1.0, tileC1, npix);
                checkStatus(s_status,"culaDgemm");
                cudaThreadSynchronize();
             }
             else if(j == 2)
             {
                if(p_option) printf("gemm\n");
                s_status = culaDgemm('N','N', npix, npix, npix, -1.0, tileA2, npix, tileB2, npix, 1.0, tileC2, npix);
                checkStatus(s_status,"culaDgemm");
                cudaThreadSynchronize();
             }
         }
     }
    culaFreeBuffers();
    checkStatus(s_status,"Error culaFreeBuffers");
    culaShutdown();
    checkStatus(s_status,"Error culaShutdown");
}
//}}}

//{{{ trmv
void trmv_calc(double *tile,double *x_sprit, double *y_sprit, int *sch, int index, int npix, int divide, char uplo, char transa, char diag)
{
    int i,npix2;
    double alpha = 1.0, beta = 1.0;
    npix2 = npix*npix;
    double *dx, *dL;
    culaStatus status;
    cublasAlloc( npix*npix, sizeof(double), (void**)&dL);
    cublasAlloc( npix, sizeof(double), (void**)&dx);
    cublasHandle_t handle;
    cublasCreate_v2(&handle);
    cublasOperation_t u, t, d;
    if(uplo == 'L') u = CUBLAS_FILL_MODE_LOWER;
    else if(uplo == 'U') u = CUBLAS_FILL_MODE_UPPER;
    if(transa == 'N') t = CUBLAS_OP_N;
    else if(transa == 'T') t = CUBLAS_OP_T;
    else if(transa == 'C') t = CUBLAS_OP_C;
    if(diag == 'N') d = CUBLAS_DIAG_NON_UNIT;
    else if(diag == 'U') d = CUBLAS_DIAG_UNIT;

    if(sch[index*4]==10)
    {
        cudaMemcpy(dL,tile,npix2*sizeof(double),cudaMemcpyHostToDevice);
        cudaMemcpy(dx,x_sprit,npix*sizeof(double),cudaMemcpyHostToDevice);
        cublasDtrmv_v2( handle,u,t,d, npix, dL, npix, dx, 1);
        /*y <- L*x + y */
        cudaMemcpy(y_sprit,dx,npix*sizeof(double),cudaMemcpyDeviceToHost);
    }
    else if(sch[index*4]==11)
    {
        status = culaDgemv( 'N', npix, npix, alpha, tile, npix, x_sprit, 1, beta, y_sprit, 1);
        checkStatus(status, "culaDgemv");
        /*y <- A*x + y */
    }

    cublasFree(dL);
    cublasFree(dx);
    for(i=0;i<divide;i++);
    {
        cudaFreeHost(x_sprit);
        cudaFreeHost(y_sprit);
        cublasDestroy_v2(handle);
    }
}
//}}}

// vim: foldmethod=marker
