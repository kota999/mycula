//{{{ header files
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<sys/time.h>
#include<cuda.h>
#include<cuda_runtime.h>
#include<cuda_runtime_api.h>
#include<cula.h>
#include<cula_device.h>
#include<cula_status.h>
#include<cula_lapack.h>
#include<cula_lapack_device.h>
#include<cula_blas.h>
#include<cula_scalapack.h>
//}}}

//{{{ utility
inline double get_dtime(void)
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return ((double)(tv.tv_sec)+(double)(tv.tv_usec)*0.001*0.001);
}

void print_tile(double *tile, int npix,int index)
{
    int i, j;
    printf("print tile matrix %d\n", index);
    for(i=0;i<npix;i++)
    {
        for(j=0;j<npix;j++)
        {
            printf("%f ", tile[npix*i + j]);
        }
        printf("\n");
    }
}

void checkStatus(culaStatus status, const char* funcname)
{
    if (!status)
        return;

    if(status == culaArgumentError) printf("%s Invalid value for parameter %d\n",funcname,culaGetErrorInfo());
    else if(status == culaDataError) printf("cula %s Data error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaBlasError) printf("cublas %s error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaRuntimeError) printf("cula %s Runtime error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaNotInitialized) printf("culaNotInitialized\n");
    else if(status == culaNoHardware) printf("culaNoHardware\n");
    else if(status == culaInsufficientRuntime) printf("culaInsufficientRuntime\n");
    else if(status == culaInsufficientComputeCapability) printf("culaInsufficientComputeCapability\n");
    else if(status == culaInsufficientMemory) printf("culaInsufficientMemory\n");
    else if(status == culaFeatureNotImplemented) printf("culaFeatureNotImplemented\n");
    else printf("%s\n",culaGetStatusString(status));
    culaShutdown();
    exit(EXIT_FAILURE);
}
//}}}

//{{{ pcula function
void pcula_potrf(double *cov, int npix)
{
    /*printf("npix = %d\n", npix);*/
    pculaConfig config;
    culaStatus status;
    status = pculaConfigInit(&config);
    checkStatus(status, "pculaConfigInit");
    // config is reset, ngpu = 0, disableGpuDirect = 0, nb =0
    //config.ngpu = 1;
    //config.disableGpuDirect = 1;
    /*printf("ngpu = %d\n", config.ngpu);*/
    // number of using gpu devices
    // 0 is all avilable devices
    /*printf("deviceList = %d\n",config.deviceList[0]);*/
    // use device-List .
    // 0 is default device-List
    /*printf("enable GPU-Direct = %d\n",config.disableGpuDirect);*/
    // GPU-Direct peer to peer On/Off
    // 0 is enable P2P
    /*printf("nb = %d\n",config.nb);*/
    // number of using blocks for divide conquer
    // 0 is auto-tuning algorithm

    status = pculaDpotrf(&config, 'L', npix, cov, npix);
    checkStatus(status, "pculaDpotrf");
}

void pcula_gemm(char transa, char transb, int m, int n, int k, double alpha, double *A, int lda, double *B, int ldb, double beta, double *C, int ldc)
{
    pculaConfig config;
    culaStatus status;
    status = pculaConfigInit(&config);
    checkStatus(status, "pculaConfigInit");
    /*printf("ngpu = %d\n", config.ngpu);*/
    /*using gpu's*/
    status = pculaDgemm(&config, transa, transb, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc);
    checkStatus(status, "pculaDgemm");
}

void pcula_trsm(char side, char uplo, char transa, char diag, int m, int n, double alpha, double *A, int lda, double *B, int ldb)
{
    pculaConfig config;
    culaStatus status;
    status = pculaConfigInit(&config);
    checkStatus(status, "pculaConfigInit");
    /*printf("ngpu = %d\n", config.ngpu);*/
    /*using gpu's*/
    pculaDtrsm(&config, side, uplo, transa, diag, m, n, alpha, A, lda, B, ldb);
    checkStatus(status, "pculaDtrsm");
}
//}}}

// vim: foldmethod=marker
