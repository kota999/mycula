//{{{ header files
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<sys/time.h>
#include<cuda.h>
#include<cuda_runtime.h>
#include<cuda_runtime_api.h>
#include<cublas.h>
#include<cublas_v2.h>
#include<cublas_api.h>
#include<cula.h>
#include<cula_device.h>
#include<cula_status.h>
#include<cula_lapack.h>
#include<cula_lapack_device.h>
#include<cula_blas.h>
//}}}

//{{{ utility
inline double get_dtime(void)
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return ((double)(tv.tv_sec)+(double)(tv.tv_usec)*0.001*0.001);
}

void print_tile(double *tile, int npix,int index)
{
    int i, j;
    printf("print tile matrix %d\n", index);
    for(i=0;i<npix;i++)
    {
        for(j=0;j<npix;j++)
        {
            printf("%f ", tile[npix*i + j]);
        }
        printf("\n");
    }
}

int get_sch_len(int divide)
{
    int i, len = 0;
    if(divide == 1) len = 1;
    else for(i=0;i<divide/2;i++) len += 2*(i+1)*(divide-i);
    return len;
}

void checkStatus(culaStatus status, const char* funcname)
{
    if (!status)
        return;

    if(status == culaArgumentError) printf("%s Invalid value for parameter %d\n",funcname,culaGetErrorInfo());
    else if(status == culaDataError) printf("cula %s Data error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaBlasError) printf("cublas %s error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaRuntimeError) printf("cula %s Runtime error (%d)\n",funcname,culaGetErrorInfo());
    else if(status == culaNotInitialized) printf("culaNotInitialized\n");
    else if(status == culaNoHardware) printf("culaNoHardware\n");
    else if(status == culaInsufficientRuntime) printf("culaInsufficientRuntime\n");
    else if(status == culaInsufficientComputeCapability) printf("culaInsufficientComputeCapability\n");
    else if(status == culaInsufficientMemory) printf("culaInsufficientMemory\n");
    else if(status == culaFeatureNotImplemented) printf("culaFeatureNotImplemented\n");
    else printf("%s\n",culaGetStatusString(status));
    culaShutdown();
    exit(EXIT_FAILURE);
}
//}}}

//{{{ simple function
void cula_potrf(double *cov, int npix)
{
    culaStatus status;
    status = culaDpotrf('L', npix, cov, npix);
    checkStatus(status, "culaDpotrf");
    /*printf("culaDpotrf\n");*/
}

void cula_trtri(double *cov, int npix)
{
    culaStatus status;
    status = culaDtrtri('L','N', npix, cov, npix);
    checkStatus(status, "culaDtrtri");
    /*printf("culaDtrtri\n");*/
}
void cula_gemm(char transa, char transb, int m, int n, int k, double alpha, double *A, int lda, double *B, int ldb, double beta, double *C, int ldc)
{
    culaStatus status;
    status = culaDgemm(transa, transb, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc);
    checkStatus(status, "culaDgemm");
    /*printf("culaDgemm\n");*/
}
void cula_trmv(double *L,double *x,int npix, char uplo, char transa, char diag)
{
    double *dL,*dx;
    cublasHandle_t handle;
    cublasCreate_v2(&handle);
    cublasOperation_t u, t, d;
    if(uplo == 'L') u = CUBLAS_FILL_MODE_LOWER;
    else if(uplo == 'U') u = CUBLAS_FILL_MODE_UPPER;
    if(transa == 'N') t = CUBLAS_OP_N;
    else if(transa == 'T') t = CUBLAS_OP_T;
    else if(transa == 'C') t = CUBLAS_OP_C;
    if(diag == 'N') d = CUBLAS_DIAG_NON_UNIT;
    else if(diag == 'U') d = CUBLAS_DIAG_UNIT;
    cublasAlloc( npix*npix, sizeof(double), (void**)&dL);
    cublasAlloc( npix, sizeof(double), (void**)&dx);
    cublasSetMatrix( npix, npix, sizeof(double), L, npix, dL, npix);
    cublasSetVector( npix, sizeof(double), x, 1, dx, 1);
    /*cublasDtrmv_v2( handle,CUBLAS_FILL_MODE_LOWER,CUBLAS_OP_N,CUBLAS_DIAG_NON_UNIT, npix, dL, npix, dx, 1);*/
    cublasDtrmv_v2( handle, u, t, d, npix, dL, npix, dx, 1);
    cublasGetMatrix( npix, npix, sizeof(double), dL, npix, L, npix);
    cublasGetVector( npix, sizeof(double), dx, 1, x, 1);
    cublasFree(dL);
    cublasFree(dx);
    cublasDestroy_v2(handle);
}

double cula_dot(double *x,int npix)
{
    double *sum = (double*)malloc(sizeof(double)) ;
    double *dx2,*dx;
    cublasHandle_t handle;
    cublasCreate_v2(&handle);
    cublasAlloc( npix, sizeof(double), (void**)&dx);
    cublasAlloc( npix, sizeof(double), (void**)&dx2);
    cublasSetVector( npix, sizeof(double), x, 1, dx, 1);
    cublasSetVector( npix, sizeof(double), x, 1, dx2, 1);
    cublasDdot_v2( handle, npix, dx, 1, dx2, 1, sum);
    cublasFree(dx);
    cublasFree(dx2);
    cublasDestroy_v2(handle);
    return sum[0];
}
//}}}

// vim: foldmethod=marker
